//
//  HourlyForecast.swift
//  SFH Weather
//
//  Created by Alexey Resnyansky on 12/6/19.
//  Copyright © 2019 Aleksei Resnianskii. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class HourlyForecast {
    private var _date: Date!
    private var _temp: Double!
    private var _weatherIcon: String!
    
    var date: Date{
        if _date == nil {
            _date = Date()
        }
        return _date
    }
    
    var temp: Double{
        if _temp == nil {
            _temp = 0.0
        }
        return _temp
    }
    
    var weatherIcon: String{
        if _weatherIcon == nil {
            _weatherIcon = ""
        }
        return _weatherIcon
    }
    class func downloadDailyForecastWeather () {
        
         let HOURLYFORECAST_URL = "https://api.weatherbit.io/v2.0/forecast/hourly?city=Kaliningrad,Kaliningrad&key=c15f86e5e81049cd90973a26100d289a&hours=24"

        
        Alamofire.request(HOURLYFORECAST_URL).responseJSON { (response) in
            let result = response.result
            
            if result.isSuccess {
                print("result is " , result.value)
            } else {
                print("no forecast data")
            }
            
            
        }
        
    }
    
}
