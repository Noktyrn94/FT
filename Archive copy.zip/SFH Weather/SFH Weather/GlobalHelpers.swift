//
//  GlobalHelpers.swift
//  SFH Weather
//
//  Created by Alexey Resnyansky on 12/5/19.
//  Copyright © 2019 Aleksei Resnianskii. All rights reserved.
//

import Foundation

func currentDateFromUnix(unixDate: Double?) -> Date? {
    if unixDate != nil {
        return Date(timeIntervalSince1970: unixDate!)
    } else {
        return Date()
        
    }
}
